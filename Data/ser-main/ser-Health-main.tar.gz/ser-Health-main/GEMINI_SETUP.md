# 🚀 دليل تفعيل AI Symptom Analyzer مع Gemini

## ✅ الوضع الحالي

النظام **جاهز تماماً** للعمل مع Gemini API! كل الكود موجود ويعمل. فقط تحتاج إضافة API Key.

---

## 📋 الخطوات المطلوبة

### الخطوة 1️⃣: احصل على Gemini API Key

1. **افتح الرابط**: [Google AI Studio - API Keys](https://aistudio.google.com/app/apikey)
2. **سجل دخول** بحساب Google
3. **اضغط على "Create API Key"** أو **"Get API key"**
4. **اختر مشروع** (أو أنشئ مشروع جديد)
5. **انسخ المفتاح** (سيكون بالشكل: `AIzaSy...`)

⚠️ **احفظ المفتاح في مكان آمن!**

---

### الخطوة 2️⃣: أضف المفتاح إلى Supabase

#### 🔧 الطريقة الأولى: عبر Supabase Dashboard (الأسهل)

1. افتح [Supabase Dashboard](https://supabase.com/dashboard/project/pfmmyzbboewiqxfxsuhk)
2. اذهب إلى **Settings** (الإعدادات) من القائمة الجانبية
3. اختر **Edge Functions** من القائمة الفرعية
4. في قسم **Secrets**، اضغط **Add new secret**
5. أضف:
   - **Name**: `GEMINI_API_KEY`
   - **Value**: الصق المفتاح اللي نسخته
6. اضغط **Save**

#### 💻 الطريقة الثانية: عبر Terminal (للمحترفين)

```bash
# تأكد إنك في مجلد المشروع
cd /home/bassem/giii

# أضف المفتاح
supabase secrets set GEMINI_API_KEY=AIzaSy...your-api-key-here
```

---

### الخطوة 3️⃣: تأكد من نشر Edge Function

```bash
# في مجلد المشروع
cd /home/bassem/giii

# نشر الـ Function
supabase functions deploy classify-symptoms
```

---

### الخطوة 4️⃣: اختبر النظام! 🎉

1. افتح الموقع: http://localhost:8080/ai-router
2. اكتب أي أعراض (بالعربي أو الإنجليزي)
3. اضغط "تحليل الأعراض"
4. شوف النتيجة من Gemini AI!

---

## 🔍 كيف تعرف إنه شغال؟

### ✅ **إذا شغال:**
- الرد سريع (1-3 ثواني)
- التحليل دقيق ومفصل
- ما في رسالة "Using preliminary analysis"

### ⚠️ **إذا مش شغال:**
- ظهور رسالة: "Using preliminary analysis"
- استخدام التحليل المحلي البسيط
- تحقق من:
  1. هل المفتاح صحيح؟
  2. هل تم نشر Edge Function؟
  3. شوف Console في المتصفح (F12)

---

## 💡 معلومات مهمة

### ✨ مميزات Gemini API:
- ✅ **مجاني** حتى 60 طلب/دقيقة
- ✅ **يدعم العربي** بشكل ممتاز
- ✅ **سريع جداً** (1-3 ثواني)
- ✅ **دقيق** في التشخيص
- ✅ **ذكي** في اقتراح التحاليل

### 🛡️ نظام الحماية (Fallback):
النظام عنده **Local Fallback** ذكي يشتغل تلقائياً لو:
- المفتاح مش موجود
- وصلت للحد الأقصى من الطلبات
- في مشكلة في الاتصال
- Gemini API مش متاح

---

## 🔗 روابط مفيدة

- [Gemini API Documentation](https://ai.google.dev/docs)
- [Google AI Studio](https://aistudio.google.com/)
- [Supabase Edge Functions Docs](https://supabase.com/docs/guides/functions)
- [مشروعك على Supabase](https://supabase.com/dashboard/project/pfmmyzbboewiqxfxsuhk)

---

## 🆘 حل المشاكل

### المشكلة: "GEMINI_API_KEY is not configured"
**الحل**: تأكد إنك ضفت المفتاح في Supabase Secrets

### المشكلة: "Gemini API failed with status 400"
**الحل**: المفتاح غلط أو منتهي، جرب مفتاح جديد

### المشكلة: "Gemini API failed with status 429"
**الحل**: وصلت للحد الأقصى، انتظر دقيقة أو استخدم مفتاح جديد

### المشكلة: النتيجة بالإنجليزي بدل العربي
**الحل**: النظام يكتشف اللغة تلقائياً من لغة الموقع

---

## 📝 ملاحظات للتطوير

### الكود الموجود:
- ✅ **AIRouter.tsx**: يستدعي Edge Function
- ✅ **classify-symptoms/index.ts**: Edge Function تستخدم Gemini
- ✅ **Local Fallback**: تحليل محلي ذكي كـ backup

### لو عايز تعدل Prompt:
افتح: `/home/bassem/giii/supabase/functions/classify-symptoms/index.ts`
عدل السطر 24 وما بعده

---

**🎯 الخلاصة**: كل شيء جاهز! فقط أضف API Key وانشر Edge Function وكل شيء سيعمل! 🚀
