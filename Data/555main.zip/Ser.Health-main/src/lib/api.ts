import { supabase, hashPassword } from './supabase';
import {
    DoctorRegistrationDTO,
    HospitalRegistrationDTO,
    VolunteerRegistrationDTO,
    PharmacyRegistrationDTO,
    LabRegistrationDTO,
    LoginDTO,
    AuthResponse,
    UserType,
} from '@/types/database.types';

// Register Doctor
export async function registerDoctor(data: DoctorRegistrationDTO): Promise<AuthResponse> {
    const passwordHash = await hashPassword(data.password);

    // Insert into auth_users
    const { data: authUser, error: authError } = await supabase
        .from('auth_users')
        .insert({
            email: data.email,
            password_hash: passwordHash,
            user_type: 'doctor',
            phone: data.phone,
        })
        .select()
        .single();

    if (authError) throw authError;

    // Insert into doctors table
    const { data: doctor, error: doctorError } = await supabase
        .from('doctors')
        .insert({
            auth_user_id: authUser.id,
            full_name: data.full_name,
            specialization: data.specialization,
            license_number: data.license_number,
            years_of_experience: data.years_of_experience,
            clinic_address: data.clinic_address,
            city: data.city,
            governorate: data.governorate,
            consultation_fee: data.consultation_fee,
            bio: data.bio,
            latitude: (data as any).latitude,
            longitude: (data as any).longitude,
        })
        .select()
        .single();

    if (doctorError) throw doctorError;

    return { user: authUser, profile: doctor };
}

// Register Hospital
export async function registerHospital(data: HospitalRegistrationDTO): Promise<AuthResponse> {
    const passwordHash = await hashPassword(data.password);

    const { data: authUser, error: authError } = await supabase
        .from('auth_users')
        .insert({
            email: data.email,
            password_hash: passwordHash,
            user_type: 'hospital',
            phone: data.phone,
        })
        .select()
        .single();

    if (authError) throw authError;

    const { data: hospital, error: hospitalError } = await supabase
        .from('hospitals')
        .insert({
            auth_user_id: authUser.id,
            hospital_name: data.hospital_name,
            registration_number: data.registration_number,
            hospital_type: data.hospital_type,
            address: data.address,
            city: data.city,
            governorate: data.governorate,
            phone_numbers: data.phone_numbers,
            emergency_phone: data.emergency_phone,
            website_url: data.website_url,
            total_beds: data.total_beds,
            latitude: (data as any).latitude,
            longitude: (data as any).longitude,
        })
        .select()
        .single();

    if (hospitalError) throw hospitalError;

    return { user: authUser, profile: hospital };
}

// Register Volunteer
export async function registerVolunteer(data: VolunteerRegistrationDTO): Promise<AuthResponse> {
    const passwordHash = await hashPassword(data.password);

    const { data: authUser, error: authError } = await supabase
        .from('auth_users')
        .insert({
            email: data.email,
            password_hash: passwordHash,
            user_type: 'volunteer',
            phone: data.phone,
        })
        .select()
        .single();

    if (authError) throw authError;

    const { data: volunteer, error: volunteerError } = await supabase
        .from('volunteers')
        .insert({
            auth_user_id: authUser.id,
            full_name: data.full_name,
            national_id: data.national_id,
            date_of_birth: data.date_of_birth,
            gender: data.gender,
            address: data.address,
            city: data.city,
            governorate: data.governorate,
            skills: data.skills,
            languages: data.languages,
            bio: data.bio,
            latitude: (data as any).latitude,
            longitude: (data as any).longitude,
        })
        .select()
        .single();

    if (volunteerError) throw volunteerError;

    return { user: authUser, profile: volunteer };
}

// Register Pharmacy
export async function registerPharmacy(data: PharmacyRegistrationDTO): Promise<AuthResponse> {
    const passwordHash = await hashPassword(data.password);

    const { data: authUser, error: authError } = await supabase
        .from('auth_users')
        .insert({
            email: data.email,
            password_hash: passwordHash,
            user_type: 'pharmacy',
            phone: data.phone,
        })
        .select()
        .single();

    if (authError) throw authError;

    const { data: pharmacy, error: pharmacyError } = await supabase
        .from('pharmacies')
        .insert({
            auth_user_id: authUser.id,
            pharmacy_name: data.pharmacy_name,
            license_number: data.license_number,
            pharmacist_name: data.pharmacist_name,
            address: data.address,
            city: data.city,
            governorate: data.governorate,
            phone_numbers: data.phone_numbers,
            delivery_available: data.delivery_available,
            online_ordering: data.online_ordering,
            latitude: (data as any).latitude,
            longitude: (data as any).longitude,
        })
        .select()
        .single();

    if (pharmacyError) throw pharmacyError;

    return { user: authUser, profile: pharmacy };
}

// Register Lab
export async function registerLab(data: LabRegistrationDTO): Promise<AuthResponse> {
    const passwordHash = await hashPassword(data.password);

    const { data: authUser, error: authError } = await supabase
        .from('auth_users')
        .insert({
            email: data.email,
            password_hash: passwordHash,
            user_type: 'lab',
            phone: data.phone,
        })
        .select()
        .single();

    if (authError) throw authError;

    const { data: lab, error: labError } = await supabase
        .from('labs')
        .insert({
            auth_user_id: authUser.id,
            lab_name: data.lab_name,
            license_number: data.license_number,
            lab_director_name: data.lab_director_name,
            address: data.address,
            city: data.city,
            governorate: data.governorate,
            phone_numbers: data.phone_numbers,
            home_service_available: data.home_service_available,
            average_turnaround_time: data.average_turnaround_time,
            latitude: (data as any).latitude,
            longitude: (data as any).longitude,
        })
        .select()
        .single();

    if (labError) throw labError;

    return { user: authUser, profile: lab };
}

// Login
export async function login(data: LoginDTO): Promise<AuthResponse> {
    const passwordHash = await hashPassword(data.password);

    // Get user from auth_users
    const { data: authUser, error: authError } = await supabase
        .from('auth_users')
        .select('*')
        .eq('email', data.email)
        .eq('password_hash', passwordHash)
        .single();

    if (authError) throw new Error('Invalid email or password');

    // Get profile based on user type
    let profile;
    let tableName: string;

    if (authUser.user_type === 'pharmacy') {
        tableName = 'pharmacies';
    } else {
        tableName = `${authUser.user_type}s`;
    }

    const { data: profileData, error: profileError } = await supabase
        .from(tableName)
        .select('*')
        .eq('auth_user_id', authUser.id)
        .single();

    if (profileError) throw profileError;

    profile = profileData;

    // Update last login
    await supabase
        .from('auth_users')
        .update({ last_login: new Date().toISOString() })
        .eq('id', authUser.id);

    return { user: authUser, profile };
}

// Get all users by type (for admin)
export async function getUsersByType(userType: UserType) {
    let tableName: string;
    if (userType === 'pharmacy') {
        tableName = 'pharmacies';
    } else {
        tableName = `${userType}s`;
    }


    const { data, error } = await supabase
        .from(tableName)
        .select(`
            *,
            auth_users!inner(*)
        `)
        .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
}

// Get verified users (for public website)
export async function getVerifiedUsers(userType: UserType) {
    let tableName: string;
    if (userType === 'pharmacy') {
        tableName = 'pharmacies';
    } else {
        tableName = `${userType}s`;
    }

    const { data, error } = await supabase
        .from(tableName)
        .select(`
            *,
            auth_users!inner(*)
        `)
        .eq('verified', true)
        .eq('auth_users.status', 'active')
        .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
}

// Update user status (for admin)
export async function updateUserStatus(userId: string, status: 'active' | 'suspended' | 'rejected') {
    const { data, error } = await supabase
        .from('auth_users')
        .update({ status })
        .eq('id', userId)
        .select()
        .single();

    if (error) throw error;
    return data;
}

// Verify user (for admin)
export async function verifyUser(userType: UserType, profileId: string) {
    let tableName: string;
    if (userType === 'pharmacy') {
        tableName = 'pharmacies';
    } else {
        tableName = `${userType}s`;
    }


    const { data, error } = await supabase
        .from(tableName)
        .update({ verified: true })
        .eq('id', profileId)
        .select()
        .single();

    if (error) throw error;

    // Also update auth status to active
    const { data: profile } = await supabase
        .from(tableName)
        .select('auth_user_id')
        .eq('id', profileId)
        .single();

    if (profile) {
        await updateUserStatus(profile.auth_user_id, 'active');
    }

    return data;
}
// Update user profile (for admin)
export async function updateUserProfile(userType: UserType, profileId: string, data: any) {
    let tableName: string;
    if (userType === 'pharmacy') {
        tableName = 'pharmacies';
    } else {
        tableName = `${userType}s`;
    }

    const { data: updatedData, error } = await supabase
        .from(tableName)
        .update(data)
        .eq('id', profileId)
        .select()
        .single();

    if (error) throw error;
    return updatedData;
}

// Delete user profile and auth user
export async function deleteUserProfile(userType: UserType, profileId: string, authUserId: string) {
    let tableName: string;
    if (userType === 'pharmacy') {
        tableName = 'pharmacies';
    } else {
        tableName = `${userType}s`;
    }

    // Delete profile first
    const { error: profileError } = await supabase
        .from(tableName)
        .delete()
        .eq('id', profileId);

    if (profileError) throw profileError;

    // Delete auth user
    const { error: authError } = await supabase
        .from('auth_users')
        .delete()
        .eq('id', authUserId);

    if (authError) throw authError;

    return true;
}

// Get Admin Stats
export async function getAdminStats() {
    const [doctors, hospitals, volunteers, pharmacies, labs] = await Promise.all([
        supabase.from('doctors').select('*', { count: 'exact', head: true }),
        supabase.from('hospitals').select('*', { count: 'exact', head: true }),
        supabase.from('volunteers').select('*', { count: 'exact', head: true }),
        supabase.from('pharmacies').select('*', { count: 'exact', head: true }),
        supabase.from('labs').select('*', { count: 'exact', head: true }),
    ]);

    const [pDoctors, pHospitals, pVolunteers, pPharmacies, pLabs] = await Promise.all([
        supabase.from('doctors').select('*', { count: 'exact', head: true }).eq('verified', false),
        supabase.from('hospitals').select('*', { count: 'exact', head: true }).eq('verified', false),
        supabase.from('volunteers').select('*', { count: 'exact', head: true }).eq('verified', false),
        supabase.from('pharmacies').select('*', { count: 'exact', head: true }).eq('verified', false),
        supabase.from('labs').select('*', { count: 'exact', head: true }).eq('verified', false),
    ]);

    return {
        doctors: doctors.count || 0,
        hospitals: hospitals.count || 0,
        volunteers: volunteers.count || 0,
        pharmacies: pharmacies.count || 0,
        labs: labs.count || 0,
        pending: {
            doctor: pDoctors.count || 0,
            hospital: pHospitals.count || 0,
            volunteer: pVolunteers.count || 0,
            pharmacy: pPharmacies.count || 0,
            lab: pLabs.count || 0,
        }
    };
}

