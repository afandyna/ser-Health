# 🔐 بيانات تسجيل الدخول للأدمن

## معلومات الحساب الافتراضي

### 📧 البريد الإلكتروني:
```
admin@ser-health.com
```

### 🔑 كلمة المرور:
```
admin123
```

---

## 🚀 طريقة التفعيل السريعة:

### الخطوة 1: افتح Supabase Dashboard
1. اذهب إلى: https://supabase.com/dashboard
2. اختر مشروعك
3. من القائمة الجانبية، اختر **SQL Editor**

### الخطوة 2: نفذ الـ SQL
1. افتح ملف: `/supabase/migrations/20260215_insert_admin_data.sql`
2. انسخ **كل** محتوى الملف
3. الصقه في SQL Editor
4. اضغط **Run** أو **Ctrl+Enter**

### الخطوة 3: تحقق من النجاح
يجب أن ترى في النتائج:
```
email: admin@ser-health.com
user_type: admin
status: active
full_name: مدير النظام - Admin
role: super_admin
```

✅ إذا ظهرت هذه البيانات، تم إنشاء الحساب بنجاح!

---

## 🔐 تسجيل الدخول:

1. افتح: `http://localhost:8080/login`
2. أدخل:
   - **البريد**: `admin@ser-health.com`
   - **كلمة المرور**: `admin123`
3. اضغط "تسجيل الدخول"
4. بعد النجاح، اذهب إلى: `http://localhost:8080/admin`

---

4. **Hash كلمة المرور**:
   - كلمة المرور: `admin123`
   - Hash (SHA-256): `240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9`

5. **إنشاء حسابات أدمن إضافية**:
   ```sql
   -- مثال لإنشاء أدمن جديد
   INSERT INTO auth_users (email, password_hash, user_type, status, email_verified)
   VALUES (
       'admin2@ser-health.com',
       'YOUR_HASHED_PASSWORD_HERE',
       'admin',
       'active',
       true
   );

   INSERT INTO admins (auth_user_id, full_name, role)
   SELECT id, 'اسم المدير', 'admin'
   FROM auth_users
   WHERE email = 'admin2@ser-health.com';
   ```

---

## 🔧 تحديثات مطلوبة في الكود:

### 1. تحديث TypeScript Types:
أضف نوع "admin" في `/src/types/database.types.ts`:

```typescript
export type UserType = 'doctor' | 'hospital' | 'volunteer' | 'pharmacy' | 'lab' | 'admin';

export interface Admin {
    id: string;
    auth_user_id: string;
    full_name: string;
    role: string;
    permissions: Record<string, any>;
    created_at: string;
    updated_at: string;
}
```

### 2. تحديث API:
في `/src/lib/api.ts`، الدالة `login()` تدعم الأدمن تلقائياً لأنها تستخدم `user_type` من قاعدة البيانات.

### 3. حماية صفحة الأدمن:
أضف middleware للتحقق من نوع المستخدم:

```typescript
// في AdminDashboard.tsx
useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    if (user.user_type !== 'admin') {
        navigate('/login');
    }
}, []);
```

---

## 🚀 خطوات تسجيل الدخول:

1. افتح صفحة تسجيل الدخول: `http://localhost:8080/login`
2. أدخل البريد الإلكتروني: `admin@ser-health.com`
3. أدخل كلمة المرور: `admin123`
4. اضغط "تسجيل الدخول"
5. بعد النجاح، انتقل إلى: `http://localhost:8080/admin`

---

## 📊 الصلاحيات:

الحساب الافتراضي له صلاحيات كاملة:
- ✅ عرض جميع المستخدمين
- ✅ الموافقة على التسجيلات
- ✅ رفض التسجيلات
- ✅ تعديل البيانات
- ✅ تعليق الحسابات

---

## 🔒 أمان:

⚠️ **تحذيرات أمنية**:
1. لا تستخدم SHA-256 في الإنتاج - استخدم bcrypt
2. غير كلمة المرور الافتراضية فوراً
3. أضف 2FA للحسابات الإدارية
4. سجل جميع عمليات الأدمن (audit log)
5. استخدم HTTPS في الإنتاج
